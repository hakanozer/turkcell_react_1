import React, { useEffect, useMemo, useState } from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import { Redirect } from 'react-router-dom'
import NewsCard from './components/NewsCard'
import { allNews } from './services'
import { MotionScreen } from 'react-motion-layout';

export default function News() {

    const [newsArr, setNewsArr] = useState([])
    const [nid, setNid] = useState(0)
    const [r_status, setR_status] = useState(false)

    useEffect(() => {
        //setNewsArr(newsResult())
        //console.log(newsResult())
        // newsResult()
    }, [])




    const newsResult = useMemo( () => {
        const params = { "sources": "google-news-in" }
        allNews(params).then( response => {
            console.log( "call" )
            const news = response.data.articles
            setNewsArr(news)
            localStorage.setItem("news", JSON.stringify(news))
        })
    }, [])


    function gotoDetail(nid) {
        setNid(nid)
        setR_status(true)
    }

    return (
        <Container>
            { r_status && <Redirect to={`/detail/`+nid} /> }
            <h1>News</h1>
            <hr />
            <MotionScreen>
            <Row>
            { newsArr.map( (item, index) => {
                return (
                    <Col key={index} sm={4} style={{ marginBottom: 10, }}><NewsCard item={item} btnClick = { () => gotoDetail(index) } index={index} /></Col>
                )
            })}
            </Row>
            </MotionScreen>
        </Container>
    )
}
