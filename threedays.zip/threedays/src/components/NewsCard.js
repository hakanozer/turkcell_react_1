import React, { useCallback } from 'react'
import { Card, Button } from 'react-bootstrap'
import { useHistory } from 'react-router-dom';
import { SharedElement, MotionScene, useMotion } from 'react-motion-layout';

export default function NewsCard( { item, btnClick, index } ) {

    const history = useHistory();
    const withTransition = useMotion(`story-${index}`);
    const callback = useCallback(() => history.push(`/detail/${index}`));

    return (
        <MotionScene name={`story-${index}`} >
        <SharedElement.Image animationKey="big-image" src={item.urlToImage} />
        <SharedElement.Text animationKey="text-main">
            <Card>
                <Card.Img variant="top" />
                <Card.Body>
                    <Card.Title>{ item.title }</Card.Title>
                    <Card.Text>
                    { item.description }
                    </Card.Text>
                    <Button  onClick={withTransition(callback)} variant="primary">Go somewhere</Button>
                </Card.Body>
            </Card>
        </SharedElement.Text>
        </MotionScene>
        
    )
}
