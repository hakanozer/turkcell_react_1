
  const UserWith = WrapperComponet => {
    const data = "new data"
    return props =>  <WrapperComponet data={data} { ...props } />
  }

  const UserDetailX = props => {
    return (
      <div>
        Pull : { props.data }
      </div>
    );
  };

  export default UserWith(UserDetailX)