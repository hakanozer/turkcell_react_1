import { memo, useEffect, useLayoutEffect, useState, useMemo } from 'react';
import UserDetailX from './User';
import { useForm } from 'react-hook-form';
import Header from './components/Header';
import { Container } from 'react-bootstrap';

function App( { content } ) {

  const initData = [
    { id: 1, content: "Detail -1" },
    { id: 2, content: "Detail -2" }
  ]

  const [data, setData] = useState(initData)
  const [title, setTitle] = useState("")
  const [formData, setFormData] = useState()
  const [count, setCount] = useState(0)
  const [headerTitle, setHeaderTitle] = useState("Site Title APP")
  const [dataArr, setDataArr] = useState([])

  useEffect(() => {
    console.log("useEffect Count Call")
  }, [count])

  useEffect(() => {
    console.log("useEffect call")
    setTitle("Hello title")
  }, [])


  useLayoutEffect(() => {
    console.log("useLayoutEffect call")
    setTitle("Hello App")
  }, [])

  const call = a => b => a > b;
  const end = call(100)(50)
  console.log(end)


  const userDetail = ( props ) => {
    // ...
    const data = "new data"
    return (
      <div>
        { data }
      </div>
    )
  }


  const { register, handleSubmit, errors } = useForm(); // initialize the hook
  const onSubmit = (data) => {
    console.log(data);
    setFormData(data)
  };

  function sum( a, b) {
    return a + b;
  } 
  console.log("Sum : " + sum(10,30))

  const sumCount = () => {
    setCount( count => count + 1 )
    setHeaderTitle("Site Title APP Y")
  }

  const headerTitleChange = () => {
    setHeaderTitle("Site Title APP X")
    setDataArr(dataResult)
    //console.log(dataResult)
  }
  
  const dataResult = useMemo( () => {
    var arr = []
    for (let index = 0; index < 10; index++) {
      arr.push(index)
    }
    console.log("dataResult call")
    return arr
  }, [count] )


  return (
    <Container>
    <div className="App">
      <Header title={headerTitle}></Header>
      <h4> { count } </h4>
      <button onClick={ sumCount }> Sum Count </button>
      <button onClick={ headerTitleChange }> Title Change </button>
      <h1> { title } </h1>

      <UserDetailX></UserDetailX>
      { data.map( (item, index) => {
        return( <p key={index}> { item.content }  </p> )
      } ) }

    <form onSubmit={handleSubmit(onSubmit)}>
      <input name="firstname" ref={register} /> {/* register an input */}
      <input name="lastname" ref={register({ required: true })} />
      {errors.lastname && 'Last name is required.'}
      <input name="age" ref={register({ pattern: /\d+/ })} />
      {errors.age && 'Please enter number for age.'}
      <input type="submit" />
    </form>

    <div>{JSON.stringify(formData)}</div>
    <div> { JSON.stringify(dataArr) } </div>
    </div>
    </Container>
  );
}

export default App;
