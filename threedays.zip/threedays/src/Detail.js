import React, { useEffect, useState } from 'react'
import { Container } from 'react-bootstrap'
import { Redirect, useHistory, browserHistory } from 'react-router-dom'

const Detail = ( props ) => {


    const [ locationKeys, setLocationKeys ] = useState([])
    const history = useHistory()

    useEffect(() => {
        return history.listen(location => {
          if (history.action === 'PUSH') {
            setLocationKeys([ location.key ])
          }
          if (history.action === 'POP') {
            if (locationKeys[1] === location.key) {
              setLocationKeys(([ _, ...keys ]) => keys)
            } else {
              setLocationKeys((keys) => [ location.key, ...keys ])
            }
          }
        })
      }, [ locationKeys, ])


    const nid = props.match.params.nid
    const [r_status, setR_status] = useState(false)
    const [item, setItem] = useState({})
    useEffect(() => {
        const storeString = localStorage.getItem("news")
        if(storeString !== null ) {
            const json = JSON.parse(storeString)
            const item = json[nid]
            setItem(item)
        }
    }, [])

    return (
        <Container>
            { r_status && <Redirect to="/news" /> }
            <button onClick={ () => setR_status(true) }>Back</button>
            <h1>{ item.title }</h1>
            <img src={ item.urlToImage } style={{ width: 300 }} />
        </Container>
    )
}


export default Detail