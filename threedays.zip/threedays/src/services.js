import  Axios  from 'axios';

const apiKey = "38a9e086f10b445faabb4461c4aa71f8"
const ax = Axios.create({
    baseURL: "http://newsapi.org/v2/",
    timeout: 30000
})

export const allNews = async (params) => {
    params["apiKey"] = apiKey
    return await ax.get("top-headlines", { params: params });
}
