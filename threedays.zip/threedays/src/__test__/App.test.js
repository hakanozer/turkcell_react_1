import App from '../App';
import renderer from 'react-test-renderer';

describe("test app", () => {
  test("test first", () => {
    const contect = "Site Title"
    const component = renderer.create(<App content={contect} />)
    const status = component.toJSON()
    expect(status).toMatchSnapshot()
  })
})