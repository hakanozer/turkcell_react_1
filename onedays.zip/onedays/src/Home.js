import React, { useEffect } from 'react';
import { Container } from 'react-bootstrap';
import Control from './components/Control';
import NavMenu from './components/NavMenu';
import { menuItem } from './MenuData';

export default function Home() {

  useEffect(() => {

    //localStorage.setItem("menu", JSON.stringify(menuItem) )

    const jsonString = localStorage.getItem("menu");
    if ( jsonString ) {

      try {
          const json = JSON.parse(jsonString)
          json.items.map( item => {
            console.log(item.title)
          })
      } catch (error) {
        console.error(error)
      }
      
    }

  }, [])

  return (
    <>
    <Control />
    <Container>
        <NavMenu />
        <h1>Welcome Home</h1>
    </Container>
    </>
  );
}
