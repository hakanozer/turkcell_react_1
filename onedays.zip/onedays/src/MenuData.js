export const menuItem = {
    items: [
        { title: "Product -1", pid: 1 },
        { title: "Product -2", pid: 2 },
        { title: "Product -3", pid: 3 },
        { title: "Product -4", pid: 4 },
    ]
}