import React, { useState } from 'react';
import { Container } from 'react-bootstrap';
import { Helmet } from 'react-helmet';
import Control from './components/Control';
import NavMenu from './components/NavMenu';

export default function Detail( props ) {

  console.log( props )
  const [pid, setPid] = useState(  props.match.params.pid )

  return (
    <>
    <Control />
    <Helmet>
        <title>Detail - {pid}</title>
        <meta name="description" content={` Detail Desc - `+pid} />
    </Helmet>
    <Container>
        <NavMenu />
        <h1>Welcome Detail - { pid }</h1>
    </Container>
    </>
  );
}
