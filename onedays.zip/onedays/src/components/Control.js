import React, { useEffect, useState } from 'react'
import { Redirect } from 'react-router-dom';

export default function Control() {

    const [status, setStatus] = useState(false);

    useEffect(() => {
        
        const session = sessionStorage.getItem("user")
        if ( session === null ) {
            setStatus(true)
        }

    }, [])

    return (
        <>
            { status &&  <Redirect to="/"></Redirect> } 
        </>
    )
}
