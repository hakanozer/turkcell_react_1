import { Base64 } from 'js-base64';
import React, { useEffect, useState } from 'react'
import { Button, Form, FormControl, Nav, Navbar, NavDropdown } from 'react-bootstrap'
import { menuItem } from '../MenuData';

export default function NavMenu( { searchTxt, setSearchTxt, fncSearchBtn } ) {

    const [mail, setMail] = useState("")

    useEffect(() => {
        const session = sessionStorage.getItem("user")
        if ( session !== null ) {
            const txt = decBase64(session, 3)
            setMail(txt)
        }
    }, [])


    function decBase64( data, count ) {
        var decTxt = data;
        for (let index = 0; index < count; index++) {
            decTxt = Base64.decode(decTxt);
        } 
        return decTxt;
    }

    return (
        <Navbar bg="light" expand="lg">
            <Navbar.Brand href="/">React-Bootstrap</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="mr-auto">
                <Nav.Link href="/">App</Nav.Link>
                <Nav.Link href="/home">Home</Nav.Link>
                <NavDropdown title="Dropdown" id="basic-nav-dropdown">

                    { menuItem.items.map( (item, index) => {
                        return (
                        <NavDropdown.Item key={index} href={`/detail/`+item.pid}>{item.title}</NavDropdown.Item>
                        )
                    } ) }
                    
                    
                    <NavDropdown.Divider />
                    <NavDropdown.Item href="#action/3.4">Separated link</NavDropdown.Item>
                </NavDropdown>
                { mail !== "" && <Nav.Link>{mail}</Nav.Link> }  
                </Nav>
                <Form inline>
                <FormControl value={searchTxt && searchTxt} onChange={ (evt) => { setSearchTxt && setSearchTxt(evt.target.value) } } type="text" placeholder="Search" className="mr-sm-2" />
                <Button onClick={fncSearchBtn && fncSearchBtn} variant="outline-success">Search</Button>
                </Form>
            </Navbar.Collapse>
        </Navbar>
    )
}
