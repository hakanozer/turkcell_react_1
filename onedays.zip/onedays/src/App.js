import { Base64 } from "js-base64";
import { useEffect, useRef, useState } from "react";
import { Button, Col, Container, Form, Row } from "react-bootstrap";
import { Helmet } from "react-helmet";
import { Redirect } from "react-router-dom";
import NavMenu from "./components/NavMenu";

function App() {

  const txtMailRef = useRef()
  const txtPassRef = useRef()

  const [ mail, setMail ] = useState("")
  const [ pass, setPass ] = useState("")
  const [searchTxt, setSearchTxt] = useState("Search...")
  const [r_status, setR_status] = useState(false)

  useEffect(() => {
    console.log("useEffect call -1")
  }, [])

  useEffect(() => {
    console.log("useEffect call -2")
  }, [mail])

  useEffect(() => {
    console.log("useEffect call -3")
    return () => {
      setMail("ali@ali.com")
    };
  }, [pass])


  function fncSend( data ) {
    console.log("fncSend call " + data)
  }

  const fncArrowSend = ( data ) => {
    if ( mail === '' ) {
      error(txtMailRef)
    }else if ( pass === '' ) {
      error(txtPassRef)
    }else {

      if ( mail === 'ali@ali.com' && pass === '12345' ) {
        sessionStorage.setItem("user",  encode(mail, 3) )
        setR_status(true)
      }

    }
  }

  function encode( data, count ) {
    var stEncode = data;
    for (let index = 0; index < count; index++) {
      stEncode = Base64.encode(stEncode);
    }
    return stEncode;
  }

  function error( refObject ) {
    refObject.current.focus()
    refObject.current.style.backgroundColor = "#ececec";
  }


  const fncSearchBtn = () => {
    console.log("fncSearchBtn Call : " + searchTxt)
  }

  return (
    <>
    { r_status && <Redirect to="/home" /> }
    <Helmet>
        <title>App Dashboard</title>
        <meta name="description" content="App application" />
    </Helmet>
     <Container>
       <NavMenu searchTxt={searchTxt} setSearchTxt={setSearchTxt} fncSearchBtn={fncSearchBtn} />
       <Row>
         <Col></Col>
         <Col>
            <h1>User Login</h1>
            <Form.Control ref={txtMailRef} value={mail} onChange={ (evt) => setMail(evt.target.value) } placeholder="Mail"></Form.Control><br></br>
            <Form.Control ref={txtPassRef} value={pass} onChange={ (evt) => setPass(evt.target.value) }  type="password" placeholder="Password"></Form.Control><br></br>
            <Button onClick={ () => fncArrowSend("React Data") } variant="success">Send</Button>
         </Col>
         <Col></Col>
       </Row>
       <h4> {searchTxt} </h4>
     </Container>
     </>
  );
}

export default App;
