import { add_note, remove_note, list_note } from '../r_types/NoteTypes'

export const fncAddNote = ( text, date ) => {
    const action = {
        type: add_note,
        text: text,
        date: date
    }
    return action
}

export const fncRemoveNote = ( id ) => {
    const action = {
        type: remove_note,
        id: id
    }
    return action
}

export const fncNoteList = ( ) => {
    const action = {
        type: list_note
    }
    return action
}