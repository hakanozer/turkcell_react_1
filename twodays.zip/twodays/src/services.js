import  Axios  from 'axios';

const user = "admin"
const pass = "12345"
const token = Buffer.from(`${user}:${pass}`, 'utf8').toString('base64')
console.log(token)

const ref = "5380f5dbcc3b1021f93ab24c3a1aac24"
const ax = Axios.create({
    baseURL: "http://jsonbulut.com/json/",
    timeout: 30000,
    //auth: {
      //  username: user,
        //password: pass
    //}
})

export const allProduct = async (params) => {
    params["ref"] = ref
    return await ax.get("product.php", { params: params });
}
