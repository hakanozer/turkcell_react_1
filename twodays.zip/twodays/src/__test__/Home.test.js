import { render, screen } from '@testing-library/react';
import Home from '../Home';

test('Home Test Title', () => {
  render(<Home />);
  const linkElement = screen.getByText(/Site Title/i);
  expect(linkElement).toBeInTheDocument();
});

test('Home Test Data', () => {
    render(<Home />);
    const linkElement = screen.getByText(/Sample Data/i);
    expect(linkElement).toBeInTheDocument();
  });