import React, { createContext, useState } from 'react'

export const Context = createContext()
const ContextProvider = (props) => {
    const [title, setTitle] = useState("Site Title")
    const fncTitle = () => {
        setTitle("Fnc Title")
    }

    return (
        <Context.Provider value={{
            title: title,
            fncTitle: fncTitle
        }} >
            <h1>Header</h1>
           { props.children } 
        </Context.Provider>
    )

}

export default ContextProvider
