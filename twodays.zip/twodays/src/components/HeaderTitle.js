import ContextProvider, {Context} from '../providers/ContextProvider'

export const HeaderTitle = () => {
    return (
        <Context.Consumer>
            { (context) => (
                
                <div>
                    <h3> { context.title } </h3>
                    <h3> Sample Data </h3>
                </div>
            )}
        </Context.Consumer>
    )
}