export const HeaderBack = (props) => {
    return (
        <div> {props.children} </div>
    )
}