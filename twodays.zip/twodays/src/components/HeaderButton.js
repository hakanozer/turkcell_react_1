import ContextProvider, {Context} from '../providers/ContextProvider'

export const HeaderButton = () => {
    return (
        <Context.Consumer>
            { (context) => (
                <button onClick={ context.fncTitle }>Click Button</button>
            )}
        </Context.Consumer>
    )
}