import { HeaderBack } from "./HeaderBack"
import { HeaderButton } from "./HeaderButton"
import { HeaderTitle } from "./HeaderTitle"

export const HeaderContainer = () => {
    return (
        <HeaderBack>
            <HeaderTitle></HeaderTitle>
            <HeaderButton></HeaderButton>
        </HeaderBack>
    )
}