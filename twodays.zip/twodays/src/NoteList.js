import React, { useEffect, useState } from 'react'
import { connect } from 'react-redux'
import { fncNoteList, fncRemoveNote } from './r_actions/NoteActions'

function NoteList( props) {

    function fncRemove( id ) {
        props.fncRemoveNote(id)
    }

    const [obj, setObj] = useState(null)
    useEffect(() => {
        setObj(fncList())
    }, [])

    const fncList = () => {
        const {obj} = props
        return obj.map(( item, index ) => {
            return (<li key={index}> { item.text } - {item.date } - <button  onClick={ () => fncRemove(item.id) }>Delete</button></li>)
        })
    }

    return (
        <div>
            { obj }
        </div>
    )
}

function mapState( state ) {
    return {
        obj: state
    }
}

export default connect( mapState, { fncRemoveNote, fncNoteList } )(NoteList)

