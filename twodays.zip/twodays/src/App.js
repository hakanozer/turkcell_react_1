import { useEffect, useState } from "react";
import { allProduct } from "./services";


function App() {

  const [proArr, setProArr] = useState([])

  useEffect(() => {
    productCall()
  }, [])

  function productCall() {
    const params = {"start" : 0}
      allProduct(params).then( response => {
        const arr = response.data.Products[0].bilgiler
        console.log( arr )
        setProArr( arr )
      })
  }

  return (
    <>
      <button onClick={ productCall }>Product Call</button>

      <div> { JSON.stringify(proArr) } </div>

    </>
  );
}

export default App;
