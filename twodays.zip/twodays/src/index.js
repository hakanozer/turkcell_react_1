import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

import reportWebVitals from './reportWebVitals';
import {
  BrowserRouter as Router,
  Route
} from 'react-router-dom'

import App from './App';
import Home from './Home';
import Note from './Note';

import { Provider } from 'react-redux'
import { createStore } from 'redux'
import { noteFnc } from './r_reducers/NoteReducer'
import NoteList from './NoteList';

const store = createStore(noteFnc, window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__())

const router = 
<Provider store={store}>
  <Router>
    <Route exact path="/" component={App} ></Route>
    <Route path="/home" component={Home} ></Route>
    <Route path="/note" component={Note} ></Route>
    <Route path="/notelist" component={NoteList} ></Route>
  </Router>
</Provider>


ReactDOM.render(
  router,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
