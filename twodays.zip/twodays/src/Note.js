import React, { useState } from 'react'
import { connect } from 'react-redux'
import { fncAddNote, fncRemoveNote, fncNoteList } from './r_actions/NoteActions'

function Note( props ) {

    const [text, setText] = useState("")
    const [date, setDate] = useState("")

    function fncInsert() {
        props.fncAddNote(text, date)
    }

    function fncRemove( id ) {
        props.fncRemoveNote(id)
    }

    const fncList = () => {
        const {obj} = props
        return obj.map(( item, index ) => {
            return (<li key={index}> { item.text } - {item.date } - <button  onClick={ () => fncRemove(item.id) }>Delete</button></li>)
        })
    }

    return (
        <div>
            <h1>Note Module</h1>
            <input value={text} onChange={(evt) => setText(evt.target.value)}></input>
            <input type="date" value={date} onChange={(evt) => setDate(evt.target.value)}></input>
            <button onClick={ fncInsert } > Note Add</button>
            <ul>
                { fncList() }
            </ul>
        </div>
    )
}

function mapState( state ) {
    return {
        obj: state
    }
}

export default connect( mapState, { fncAddNote,fncRemoveNote, fncNoteList } )(Note)
