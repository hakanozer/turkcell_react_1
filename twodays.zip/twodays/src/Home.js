import React from 'react'
import { HeaderContainer } from './components/HeaderContainer'
import ContextProvider from './providers/ContextProvider'


export default function Home() {
    return (
        <ContextProvider>
            <HeaderContainer></HeaderContainer>
        </ContextProvider>
    )
}




