import { useEffect } from 'react'
import { add_note, remove_note, list_note } from '../r_types/NoteTypes'


var defaultData = []
function pullResult() {
    console.log("pullResult call")
    defaultData = [
        {  
            id: Math.random(),
            text: "Sinema",
            date: "15.12.2020"
        },
        {  
            id: Math.random(),
            text: "Sinema X",
            date: "16.12.2020"
        }
    ]
}
pullResult()


const noteAdd = ( action ) => {
    let { text, date } = action
    return {
        id: Math.random(),
        text,
        date
    }
}

const deleteNote = ( state = [], id ) => {
    const deleteItems = state.filter( fitem => fitem.id !== id )
    return deleteItems
}


export const noteFnc = ( state = defaultData, action ) => {


    let obj = null
    switch (action.type) {
        case add_note:
            obj = [ ...state, noteAdd(action) ]
        return obj

        case remove_note:
            obj = deleteNote( state, action.id )
        return obj

        case list_note:
            obj = defaultData
        return obj
    
        default:
            return state
    }


}

